# Authors : Nikhil Sudireddy ,  Raghuveer Ramesh 
for i in $1/*.csv
do
  sed -i -e '1iairline,month,dom,doy,origin,dest,flight_1,flight_2,duration,missed\' $i
done
