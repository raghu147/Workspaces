import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.GZIPInputStream;


/*Utility class to Validate prediction of Missed connections */
public class Validate {

	/* Set to store Valid missed connections */
	static Set<String> validationSet;
	
	public static void main(String[] args) throws Exception {
		
		/* <validation-file.csv.gz> <predicted-file.csv> */
		
		double correct = 0.0, wrong  = 0.0;

		/* Build set with given validation file */
		buildSet(args[0]);
		
		
		InputStream fs = new FileInputStream(args[1]);
		Reader reader = new InputStreamReader(fs);

		BufferedReader br = new BufferedReader(reader);
		br = new BufferedReader(reader);
		String line;
		
		/* Loop through predicted File */
		while((line = br.readLine()) != null){
			if(validationSet.contains(line))
				correct++;
			else
				wrong ++;
			
		}

		br.close();
		
		
		/*Results */
		
		double acc = correct*100 / (correct+wrong);
		
		System.out.println("Accuracy:"+acc);
		

	}
	
	/* Function to build a set for comparison */
	public static void buildSet(String filePath) throws Exception{
		
		validationSet = new HashSet<String>();

		InputStream fs = new FileInputStream(filePath);
		InputStream gs = new GZIPInputStream(fs);
		Reader reader = new InputStreamReader(gs);

		BufferedReader br = new BufferedReader(reader);
		br = new BufferedReader(reader);
		String line;
		while((line = br.readLine()) != null){
			validationSet.add(line);
		}

		br.close();
		
	}

}
