/* Authors : Nikhil Sudireddy ,  Raghuveer Ramesh */
import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class Routing {

	/* Training data Mapper */
	public static class TrainDataMapper extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context)

				throws IOException, InterruptedException {

			String line = value.toString();

			if (!(line.startsWith("YEAR"))) {

				line = line.replace(", ", "|");
				line = line.replace("\"", "");

				String[] field = line.split(",");

				if (field.length == 110) {

					String year = field[0];
					String month = field[2];
					String dayOfMonth = field[3];
					String airline = field[6];
					String origin = field[14];
					String dest = field[23];
					String fl_num = field[10];

					String scheduled_dep = field[29].trim().equals("") ? "NA" : field[29];
					String actual_dep = field[30].trim().equals("") ? "NA" : field[30];
					String scheduled_arr = field[40].trim().equals("") ? "NA" : field[40];
					String actual_arr = field[41].trim().equals("") ? "NA" : field[41];
					String actual_elapsed_time = field[50].trim().equals("") ? "NA" : field[50];

					/* Sanity Check */
					if (!corruptLine(field)) {

						String row = year + ":" + month + ":" + dayOfMonth + ":" + airline + ":" + origin + ":" + dest
								+ ":" + scheduled_dep + ":" + scheduled_arr + ":" + actual_arr + ":" + actual_dep + ":"
								+ fl_num + ":" + actual_elapsed_time;
						String key_arline = airline;
						
						/* Mapper emits value by key=Airline */
						context.write(new Text(key_arline), new Text(row));
					}
				}
			}
		}
	}

	/* Test data Mapper */
	public static class TestDataMapper extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context)

				throws IOException, InterruptedException {

			String line = value.toString();

			if (!(line.startsWith("YEAR"))) {

				line = line.replace(", ", "|");
				line = line.replace("\"", "");

				String[] field = line.split(",");

				
				if (field.length == 111) {

					String year = field[0];
					String month = field[2];
					String dayOfMonth = field[3];
					String airline = field[6];
					String origin = field[14];
					String dest = field[23];
					String fl_num = field[10];

					String scheduled_dep = field[29].trim().equals("") ? "NA" : field[29];

					String scheduled_arr = field[40].trim().equals("") ? "NA" : field[40];

					/* Sanity Check */
					if (checkSanity(scheduled_arr, scheduled_dep)) {

						String row = year + ":" + month + ":" + dayOfMonth + ":" + airline + ":" + origin + ":" + dest
								+ ":" + fl_num + ":" + scheduled_dep + ":" + scheduled_arr;

						String key_arline = airline;
						context.write(new Text(key_arline), new Text(row));

					}
				}
			}
		}
	}

	/*
	 * Utility method that checks if given Departure and Arrival times are in proper format
	 */
	public static boolean checkSanity(String scheduledDep, String scheduledArr) {

		try {
			Integer.parseInt(scheduledArr);
			Integer.parseInt(scheduledDep);
		} catch (NumberFormatException n) {

			return false;
		}

		return true;
	}

	/* Utility method that converts Time from hhmm to Time in Number of Minutes*/
	public static int getMin(String hhmm) {

		if (hhmm.isEmpty()) {
			return 0;
		}

		int min = 0, hr = 0;

		if (hhmm.length() < 3) {
			min = Integer.parseInt(hhmm);

		} else if (hhmm.length() == 3) {

			hr = Integer.parseInt(hhmm.substring(0, 1));
			min = Integer.parseInt(hhmm.substring(1, 3));

		} else if (hhmm.length() == 4) {

			hr = Integer.parseInt(hhmm.substring(0, 2));
			min = Integer.parseInt(hhmm.substring(2, 4));

		}

		return hr * 60 + min;

	}

	/* Sanity Checker for Training Data */
	public static boolean corruptLine(String[] field) {

		int CRSArrTime = getMin(field[40]);
		int CRSDepTime = getMin(field[29]);
		int CRSElapsedTime = Integer.parseInt(field[50]);
		if (CRSArrTime == 0 || CRSDepTime == 0) {
			return true;
		}

		int timeZone = CRSArrTime - CRSDepTime - CRSElapsedTime;
		if (timeZone % 60 != 0) {
			return true;
		}

		int AirportID = Integer.parseInt(field[20]), AirportSeqID = Integer.parseInt(field[21]),
				CityMarketID = Integer.parseInt(field[22]), StateFips = Integer.parseInt(field[26]),
				Wac = Integer.parseInt(field[28]);

		if (AirportID <= 0 || AirportSeqID <= 0 || CityMarketID <= 0

				|| StateFips <= 0 || Wac <= 0) {

			return true;

		}

		String Origin = field[14], Destination = field[23], OriginCityName = field[15], DestinationCityName = field[24],
				OriginState = field[16], DestinationState = field[25], OriginStateName = field[18],
				DestinationStateName = field[27];

		if (Origin.equals("") || Destination.equals("") || OriginCityName.equals("") || DestinationCityName.equals("")
				|| OriginState.equals("") || DestinationState.equals("") || OriginStateName.equals("")
				|| DestinationStateName.equals("")) {

			return true;

		}

		int Cancelled = Integer.parseInt(field[47]);

		if (Cancelled != 1) {

			int ArrTime = getMin(field[41]), DepTime = getMin(field[30]),
					ActualElapsedTime = Integer.parseInt(field[51]);

			if (((ArrTime - DepTime - ActualElapsedTime - timeZone) / 60) % 24 != 0) {
				return true;
			}

			double ArrDelay = Double.parseDouble(field[42]), ArrDelayMinutes = Double.parseDouble(field[43]),
					ArrDelay15 = Double.parseDouble(field[44]);

			if (ArrDelay > 0 && ArrDelay != ArrDelayMinutes) {
				return true;
			}

			if (ArrDelay < 0 && ArrDelayMinutes != 0) {
				return true;
			}

			if (ArrDelayMinutes >= 15 && ArrDelay15 != 1) {
				return true;
			}

		}

		return false;

	}

	/* Training Data Reducer */
	public static class TrainDataReducer extends Reducer<Text, Text, Text, Text> {

		private static MultipleOutputs<Text, Text> out;

		protected void setup(Context context) throws IOException, InterruptedException {
			out = new MultipleOutputs<Text, Text>(context);
		}

		public void reduce(Text key, Iterable<Text> values, Context context)

				throws IOException, InterruptedException {

			
			/* HashMaps to store list of flight1 and flight2 for a pair of flights */
			/* Parent HashMap is keyed by UniqueAirport and value contains list of flights departing that airport */
			/* Child map is keyed by Day of year */
			Map<String, HashMap<Integer, ArrayList<String>>> flight1Map = new HashMap<String, HashMap<Integer, ArrayList<String>>>();
			
			
			/* Parent HashMap is keyed by UniqueAirport and value contains list of flights arriving that airport */
			Map<String, HashMap<Integer, ArrayList<String>>> flight2Map = new HashMap<String, HashMap<Integer, ArrayList<String>>>();

			
			for (Text val : values) {

				String field[] = val.toString().split(":");

				int year = Integer.parseInt(field[0]);
				int month = Integer.parseInt(field[1]);
				int dayOfMonth = Integer.parseInt(field[2]);

				String origin = field[4];
				String dest = field[5];

				/*Hashmap that stores a set of flights for a day of the */
				/* year(1-365) */
				HashMap<Integer, ArrayList<String>> row = new HashMap<Integer, ArrayList<String>>();

				Calendar c = Calendar.getInstance();
				c.set(year, month - 1, dayOfMonth);

				int dayOfYear = c.get(Calendar.DAY_OF_YEAR);

				String scheduled_dep = field[6];
				String scheduled_arr = field[7];
				String actual_arr = field[8];
				String actual_dep = field[9];
				String actual_elapsed_time = field[11];

				/* Checking for correct values of dates and start filling */
				/* HashMaps */
				
				if (!actual_arr.equals("NA") && !scheduled_arr.equals("NA") && !actual_elapsed_time.equals("NA")) {
					if (flight1Map.containsKey(dest)) {
						row = flight1Map.get(dest);

						if (row.containsKey(dayOfYear)) {
							ArrayList<String> eachDay = row.get(dayOfYear);
							eachDay.add(val.toString());
							row.put(dayOfYear, eachDay);
						} else {
							ArrayList<String> eachDay = new ArrayList<String>();
							eachDay.add(val.toString());
							row.put(dayOfYear, eachDay);
						}

					} else {

						ArrayList<String> eachDay = new ArrayList<String>();
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					}

					flight1Map.put(dest, row);
				}

				row = new HashMap<Integer, ArrayList<String>>();

				// Checking for correct values of dates
				if (!scheduled_dep.equals("NA") && !actual_dep.equals("NA") && !actual_elapsed_time.equals("NA")) {
					if (flight2Map.containsKey(origin)) {
						row = flight2Map.get(origin);

						if (row.containsKey(dayOfYear)) {
							ArrayList<String> eachDay = row.get(dayOfYear);
							eachDay.add(val.toString());
							row.put(dayOfYear, eachDay);
						} else {
							ArrayList<String> eachDay = new ArrayList<String>();
							eachDay.add(val.toString());
							row.put(dayOfYear, eachDay);
						}

					} else {

						ArrayList<String> eachDay = new ArrayList<String>();
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					}

					flight2Map.put(origin, row);
				}

			}

			/* HashMaps have been built */
			
			
			for (String airport : flight1Map.keySet()) {

				if (flight2Map.containsKey(airport)) {
					HashMap<Integer, ArrayList<String>> originsForDate = flight1Map.get(airport);
					HashMap<Integer, ArrayList<String>> destsForDate = flight2Map.get(airport);

					for (int dayOfYear : originsForDate.keySet()) {
						if (destsForDate.containsKey(dayOfYear)) {
							ArrayList<String> combinedList = new ArrayList<String>();

							combinedList.addAll(destsForDate.get(dayOfYear));

							if (destsForDate.containsKey(dayOfYear + 1))
								combinedList.addAll(destsForDate.get(dayOfYear + 1));

							getMissedConnections(originsForDate.get(dayOfYear), combinedList, key, dayOfYear, context);
						}
					}
				}
			}

		}

		
		/* Method to determine if connectinon exist in two given lists of flights*/
		
		public static void getMissedConnections(ArrayList<String> flight1List, ArrayList<String> flight2List, Text key, int dayOfYear,
				Context context) throws IOException, InterruptedException {

			for (String flight1 : flight1List) {
				String field1[] = flight1.split(":");

				int scheduled_arr = getMin(field1[7]);
				String origin_airport = field1[4];
				int act_arr = getMin(field1[8]);
				String org_fl_num = field1[10];
				int origin_elapsed_time = Integer.parseInt(field1[11]);
				int originDay = Integer.parseInt(field1[2]);

				for (String fight2 : flight2List) {
					String field2[] = fight2.split(":");

					String dest_airport = field2[5];
					int destDay = Integer.parseInt(field2[2]);
					int scheduled_dep = getMin(field2[6]);
					String des_fl_num = field2[10];
					int dest_elapsed_time = Integer.parseInt(field2[11]);
					int actual_dep = getMin(field2[9]);

					int total_elapsed_time = origin_elapsed_time + dest_elapsed_time;

					// Handling case where dates overalap
					if (destDay == originDay + 1) {
						int diff = scheduled_dep + (24 * 60 - scheduled_arr);

						if (diff >= 30 && diff <= 60) {
							// Connection found
							// connections++;

							if ((actual_dep - (1440 - act_arr)) < 30) {
								// Missed Connection found
								// missedConn ++;
								out.write(key,
										new Text(field2[1] + "," + destDay + "," + (dayOfYear + 1) + ","
												+ origin_airport + "," + dest_airport + "," + org_fl_num + ","
												+ des_fl_num + "," + (total_elapsed_time + 100*60) + "," + true),
										key.toString().replace(" ",""));
							} else {
								out.write(key,
										new Text(field2[1] + "," + destDay + "," + (dayOfYear + 1) + ","
												+ origin_airport + "," + dest_airport + "," + org_fl_num + ","
												+ des_fl_num + "," + total_elapsed_time + "," + false),
										key.toString().replace(" ",""));
							}

						}
					} else {

						int diff = scheduled_dep - scheduled_arr;
						if (diff >= 30 && diff <= 60) {
							// Connection found
							// connections++;

							if ((actual_dep - act_arr) < 30) {
								// Missed Connection found
								// missedConn ++;
								out.write(key,
										new Text(field2[1] + "," + destDay + "," + dayOfYear + "," + origin_airport
												+ "," + dest_airport + "," + org_fl_num + "," + des_fl_num + ","
												+ (total_elapsed_time + 100*60) + "," + true),
										key.toString().replace(" ",""));
							} else {
								out.write(key,
										new Text(field2[1] + "," + destDay + "," + dayOfYear + "," + origin_airport
												+ "," + dest_airport + "," + org_fl_num + "," + des_fl_num + ","
												+ total_elapsed_time + "," + false),
										key.toString().replace(" ",""));
							}
						}
					}

				}

			}

		}
	}

	public static class TestDataReducer extends Reducer<Text, Text, Text, Text> {

		private static MultipleOutputs<Text, Text> out;

		protected void setup(Context context) throws IOException, InterruptedException {
			out = new MultipleOutputs<Text, Text>(context);
		}

		public void reduce(Text key, Iterable<Text> values, Context context)

				throws IOException, InterruptedException {

			// HashMaps to store list of origins and destinations

			Map<String, HashMap<Integer, ArrayList<String>>> flight1Map = new HashMap<String, HashMap<Integer, ArrayList<String>>>();
			Map<String, HashMap<Integer, ArrayList<String>>> flight2Map = new HashMap<String, HashMap<Integer, ArrayList<String>>>();

			for (Text val : values) {

				String field[] = val.toString().split(":");

				int year = Integer.parseInt(field[0]);
				int month = Integer.parseInt(field[1]);
				int dayOfMonth = Integer.parseInt(field[2]);

				String origin = field[4];
				String dest = field[5];

				// Hashmap that stores a set of flights for a day of the
				// year(1-365)
				HashMap<Integer, ArrayList<String>> row = new HashMap<Integer, ArrayList<String>>();

				Calendar c = Calendar.getInstance();
				c.set(year, month - 1, dayOfMonth);

				int dayOfYear = c.get(Calendar.DAY_OF_YEAR);

				// Checking for correct values of dates and start filling
				// HashMaps
				if (flight1Map.containsKey(dest)) {
					row = flight1Map.get(dest);

					if (row.containsKey(dayOfYear)) {
						ArrayList<String> eachDay = row.get(dayOfYear);
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					} else {
						ArrayList<String> eachDay = new ArrayList<String>();
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					}

				} else {

					ArrayList<String> eachDay = new ArrayList<String>();
					eachDay.add(val.toString());
					row.put(dayOfYear, eachDay);
				}

				flight1Map.put(dest, row);

				row = new HashMap<Integer, ArrayList<String>>();

				// Checking for correct values of dates
				if (flight2Map.containsKey(origin)) {
					row = flight2Map.get(origin);

					if (row.containsKey(dayOfYear)) {
						ArrayList<String> eachDay = row.get(dayOfYear);
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					} else {
						ArrayList<String> eachDay = new ArrayList<String>();
						eachDay.add(val.toString());
						row.put(dayOfYear, eachDay);
					}

				} else {

					ArrayList<String> eachDay = new ArrayList<String>();
					eachDay.add(val.toString());
					row.put(dayOfYear, eachDay);
				}

				flight2Map.put(origin, row);

			}

			// Hashtables have been populated

			for (String airport : flight1Map.keySet()) {

				if (flight2Map.containsKey(airport)) {

					HashMap<Integer, ArrayList<String>> originsForDate = flight1Map.get(airport);
					HashMap<Integer, ArrayList<String>> destsForDate = flight2Map.get(airport);

					for (int dayOfYear : originsForDate.keySet()) {
						if (destsForDate.containsKey(dayOfYear)) {
							ArrayList<String> combinedList = new ArrayList<String>();

							combinedList.addAll(destsForDate.get(dayOfYear));

							if (destsForDate.containsKey(dayOfYear + 1))
								combinedList.addAll(destsForDate.get(dayOfYear + 1));

							getMissedConnections(originsForDate.get(dayOfYear), combinedList, key, dayOfYear, context);
						}
					}
				}
			}

		}

		public static void getMissedConnections(ArrayList<String> orig, ArrayList<String> dest, Text key, int dayOfYear,
				Context context) throws IOException, InterruptedException {

			for (String or : orig) {
				String field1[] = or.split(":");

				String flight1Month = field1[1];
				String flight1Origin = field1[4];
				String flight1Number = field1[6];
				int flight1Scheduled_arr = getMin(field1[8]);

				int flight1DayOfMonth = Integer.parseInt(field1[2]);

				for (String d : dest) {
					String field2[] = d.split(":");

					String flight2Dest = field2[5];
					String flight2Number = field2[6];

					int flight2DayOfMonth = Integer.parseInt(field2[2]);
					int flight2Scheduled_dep = getMin(field2[7]);

					if (flight2DayOfMonth == flight1DayOfMonth + 1) {
						int diff = flight2Scheduled_dep + (24 * 60 - flight1Scheduled_arr);

						if (diff >= 30 && diff <= 60) {

							out.write(key,
									new Text(flight1Month + "," + flight2DayOfMonth + "," + (dayOfYear + 1) + ","
											+ flight1Origin + "," + flight2Dest + "," + flight1Number + ","
											+ flight2Number + ",,"),
									key.toString().replace(" ",""));

						}
					} else {

						int diff = flight2Scheduled_dep - flight1Scheduled_arr;
						if (diff >= 30 && diff <= 60) {

							out.write(key,
									new Text(flight1Month + "," + flight2DayOfMonth + "," + dayOfYear + ","
											+ flight1Origin + "," + flight2Dest + "," + flight1Number + ","
											+ flight2Number + ",,"),
									key.toString().replace(" ",""));
						}
					}

				}

			}

		}
	}

	public static void main(String[] args) throws Exception {

		/* Use 2 Jobs, 1 to read training data and one to read Test data */

		Configuration conf = new Configuration();
		conf.set("mapred.textoutputformat.separator", ",");

		Job job1 = Job.getInstance(conf, "Routing");
		job1.setJarByClass(Routing.class);
		job1.setMapperClass(TrainDataMapper.class);
		job1.setReducerClass(TrainDataReducer.class);
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job1, new Path(args[0]));
		FileOutputFormat.setOutputPath(job1, new Path(args[2]));
		MultipleOutputs.addNamedOutput(job1, "train", TextOutputFormat.class, LongWritable.class, Text.class);
		job1.waitForCompletion(true);

		Job job2 = Job.getInstance(conf, "Routing");
		job2.setJarByClass(Routing.class);
		job2.setMapperClass(TestDataMapper.class);
		job2.setReducerClass(TestDataReducer.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job2, new Path(args[1]));
		FileOutputFormat.setOutputPath(job2, new Path(args[3]));
		MultipleOutputs.addNamedOutput(job2, "test", TextOutputFormat.class, LongWritable.class, Text.class);
		System.exit(job2.waitForCompletion(true) ? 0 : 1);

		/*
		 * Configuration conf = new Configuration();
		 * conf.set("mapred.textoutputformat.separator", ",");
		 * 
		 * Job job = Job.getInstance(conf, "Routing");
		 * job.setJarByClass(Routing.class); job.setMapperClass(M2.class);
		 * job.setReducerClass(R2.class); job.setOutputKeyClass(Text.class);
		 * job.setOutputValueClass(Text.class);
		 * FileInputFormat.addInputPath(job, new Path(args[0]));
		 * FileOutputFormat.setOutputPath(job, new Path(args[1]));
		 * System.exit(job.waitForCompletion(true) ? 0 : 1);
		 */

	}

}
