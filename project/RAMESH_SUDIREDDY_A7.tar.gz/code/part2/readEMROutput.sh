#!/bin/bash

# Arg-1  = BUCKET_NAME

clusterID=$(cat clusterID)
bucketName=$1

stepsCompleted="False"

echo "Checking cluster $clusterID and waiting for cluster to finish execution"

while [ $stepsCompleted  == "False" ]
do

	cState=`aws emr describe-cluster --cluster-id "$clusterID" --output json | jq ".Cluster.InstanceGroups[0].Status.State"`
	if [ $cState = '"TERMINATED"' ]; then
		stepsCompleted="True"
	else
		echo "Steps incomplete : Sleeping for 30 seconds"
	        sleep 30
	fi
done

echo "Cluster has terminated. Now attempting to copy output data from bucekt $1"


rm -rf output
mkdir output
aws s3 sync s3://"$bucketName"/output/ output


echo "Copied output to directory named : output"
