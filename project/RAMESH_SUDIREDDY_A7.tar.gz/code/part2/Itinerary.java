import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

public class Itinerary {
	
	/* Data structure to store an itinerary with the best duration */
	static Map<String,String> durationMap ;

	public static void main(String[] args) throws Exception {

		/*< Test-File>  <Request File> */
		
		durationMap = new HashMap<String,String>();
		
		fillMap(args[0]);
		
		
		/* open itinerary file at current path to store results */
		File file = new File("itinerary.csv");

		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);
		
		
		/* open Request file to store results */
		InputStream fs = new FileInputStream(args[1]);
		InputStream gs = new GZIPInputStream(fs);
		Reader reader = new InputStreamReader(gs);

		BufferedReader br = new BufferedReader(reader);
		br = new BufferedReader(reader);
		String line;
		while((line = br.readLine()) != null){
			
			int lastIndex = line.lastIndexOf(",");
			line = line.substring(0, lastIndex);
			String eachItinerary = durationMap.get(line);
			/* Get itinerary for request and write to file */
			if(eachItinerary != null)
			bw.write(eachItinerary+"\n");
		}

		br.close();
		bw.close();
	}
	
	
	/* Method to create a map with optimal durations for a flight */
	public static void fillMap(String filePath) throws IOException{

		InputStream fs = new FileInputStream(filePath);
		Reader reader = new InputStreamReader(fs);

		BufferedReader br = new BufferedReader(reader);
		br = new BufferedReader(reader);
		String line;
		
		
		while((line = br.readLine()) != null){
			 
			
			/* line =  year, month, day, origin, destination,f1,f2,duration */
			
			String splits[] = line.split(",");
			String key  = splits[0] + "," + splits[1] + "," + splits[2] + "," + splits[3] + "," + splits[4] ;
			String val = splits[5] + "," + splits[6] + ",";
			
			Double duration = Double.parseDouble(splits[7]);
			
			if(!durationMap.containsKey(key)){
				
				durationMap.put(key, val+duration);
			}
			else {
				String  v  = durationMap.get(key);
				Double d = Double.parseDouble(v.split(",")[2]);
				
				if(duration < d)
					durationMap.put(key, val+duration);
			}
		}

		br.close();
		
	}

}
