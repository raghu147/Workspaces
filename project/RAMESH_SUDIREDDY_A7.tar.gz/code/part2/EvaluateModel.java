/* Authors : Nikhil Sudireddy ,  Raghuveer Ramesh */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import weka.classifiers.bayes.NaiveBayes;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

public class EvaluateModel {
	public static void main(String[] args) throws Exception {

		/* <Train-folder> <test-folder>  */


		/* open Request file to store results */
		File file = new File("prediction.csv");

		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file.getAbsoluteFile());
		BufferedWriter bw = new BufferedWriter(fw);


		/* Get folder containing Training and Test files */

		File train_dir = new File(args[0]);
		File test_dir = new File(args[1]);
		File[]  train_files = train_dir.listFiles();
		File[]  test_files = test_dir.listFiles();


		/* Loop and compare corresponding training and test files for a given month*/

		if (train_files != null && test_dir != null) {
			for (File train_file : train_files) {
				for (File test_file : test_files) {

					String train_file_name = train_file.getName().toString();
					String test_file_name = test_file.getName().toString();

					if(train_file_name.equals(test_file_name))
					{

						/* Load Train file for a month*/

						ConverterUtils.DataSource source1 = new ConverterUtils.DataSource(args[0] + "/" + train_file_name);
						Instances train = source1.getDataSet();

						train.setClassIndex(train.numAttributes() - 1);

						/* Train Naive Bayes */
						NaiveBayes naiveBayes = new NaiveBayes();
						naiveBayes.buildClassifier(train);

						/* Load Test File for the corresponding month*/

						ConverterUtils.DataSource source2 = new ConverterUtils.DataSource(args[1] + "/" + test_file_name);
						Instances test = source2.getDataSet();

						test.setClassIndex(test.numAttributes() - 1);


						for (int i = 0; i < test.numInstances(); i++) {

							
							Instance testInstance = test.instance(i);

							double pred;

							try {

								/* Based on Training data, predict outcome for test data */
								pred = naiveBayes.classifyInstance(test.instance(i));
							}
							catch(Exception e){
								continue;
							}


							String predicted = test.classAttribute().value((int) pred);

							predicted = predicted.toUpperCase();

							if(predicted.equals("TRUE")){
								
								//AA,11,1,305,11697,11423,3195,3163,?,?
								//2004,7,1,JAX,STL,1541,1463
								
								String splits[]  =  testInstance.toString().split(",");
								String key = "2014," + splits[1]+ "," + splits[2] + "," + splits[4] + "," +
										splits[5] + "," + splits[6] + "," + splits[7];
										
								bw.write(key+"\n");
							}
						}
					}
				}
			}

			bw.close();
			 

		}
	}
}
