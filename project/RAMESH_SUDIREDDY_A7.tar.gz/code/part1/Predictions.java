/* Authors : Nikhil Sudireddy ,  Raghuveer Ramesh */

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class Predictions {

	/* Training data Mapper */
	public static class TrainDataMapper extends Mapper<LongWritable, Text, Text, Text> {
		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

			/* Popular airports */
			String popularAirports[] = { "ATL", "CLT", "CVG", "DTW", "MCO", "MDT", "ORD", "PIT", "AMA", "COS", "DAL",
					"DEN", "DFW", "ELP", "HOU", "IAH", "LAS", "LAX", "LBB", "MAF", "MCI", "MSP", "PHX", "SAN", "SFO",
					"SLC", "STL", "TPA", "ANC", "DCA", "PHL", "PWM", "ABQ", "ADQ", "BET", "CDV", "DLG", "DUT", "FAI",
					"JNU", "OME", "BOS", "SCC", "SEA", "ABE", "JFK", "ALB", "AUS", "BDL", "BHM" };

			/* Dates close to Holidays */
			String holidayList[] = { "01-01", "12-31", "07-03", "07-04", "11-10", "11-11", "11-29", "11-30", "12-23",
					"12-24", "12-25" };

			Set<String> airportsMap = new HashSet<String>();
			Set<String> holidaysMap = new HashSet<String>();

			for (String s : popularAirports)
				airportsMap.add(s);

			for (String s : holidayList)
				holidaysMap.add(s);

			String line = value.toString().replace("\"", "");

			if (!(line.startsWith("YEAR"))) {

				line = line.replace(", ", "|");
				String[] field = line.split(",");

				if (field.length == 110) {

					String source = field[14];
					String dest = field[23];
					String flightDate = field[5];
					String airline = field[6];
					String month = field[2];
					String dayOfMonth = field[3];
					String dayOfWeek = field[4];

					
					if (airportsMap.contains(source) && airportsMap.contains(dest)) {
						
						/* Sanity Check */
						if (!corruptLine(field) && field[42] != null && !field[42].trim().equals("")) {

							String mmdd = flightDate.substring(5, 10);
							String flightNumber = field[10];
							String CRS_DEP = field[29];
							String origin = field[14];
							boolean holiday = holidaysMap.contains(mmdd) ? true : false;
							boolean delay = (Double.parseDouble(field[42]) > 0.0) ? true : false;

							String map_value = dayOfMonth + "," + dayOfWeek + "," + flightDate + "," + airline + ","
									+ flightNumber + "," + CRS_DEP + "," + origin + "," + dest + "," + holiday + ","
									+ delay;
							String key_month = "0" + month;

							/* Mapper emits value by key=Month */
							context.write(new Text(key_month), new Text(map_value));
						}
					}

				}

			}

		}

	}

	/* Test data Mapper */
	public static class TestDataMapper extends Mapper<LongWritable, Text, Text, Text> {

		public void map(LongWritable key, Text value, Context context)

				throws IOException, InterruptedException {

			/* Popular airports */
			String popularAirports[] = { "ATL", "CLT", "CVG", "DTW", "MCO", "MDT", "ORD", "PIT", "AMA", "COS", "DAL",
					"DEN", "DFW", "ELP", "HOU", "IAH", "LAS", "LAX", "LBB", "MAF", "MCI", "MSP", "PHX", "SAN", "SFO",
					"SLC", "STL", "TPA", "ANC", "DCA", "PHL", "PWM", "ABQ", "ADQ", "BET", "CDV", "DLG", "DUT", "FAI",
					"JNU", "OME", "BOS", "SCC", "SEA", "ABE", "JFK", "ALB", "AUS", "BDL", "BHM" };

			/* Dates close to Holidays */
			String holidayList[] = { "01-01", "12-31", "07-03", "07-04", "11-10", "11-11", "11-29", "11-30", "12-23",
					"12-24", "12-25" };

			Set<String> airportsMap = new HashSet<String>();
			Set<String> holidaysMap = new HashSet<String>();

			for (String s : popularAirports)
				airportsMap.add(s);

			for (String s : holidayList)
				holidaysMap.add(s);

			String line = value.toString().replace("\"", "");

			if (!(line.startsWith("YEAR"))) {

				line = line.replace(", ", "|");
				String[] field = line.split(",");

				if (field.length == 112) {

					System.arraycopy(field, 1, field, 0, 111);

					String source = field[14];
					String dest = field[23];
					String flightDate = field[5];
					String airline = field[6];
					String month = field[2];
					String dayOfMonth = field[3];
					String dayOfWeek = field[4];

					if (airportsMap.contains(source) && airportsMap.contains(dest)) {
						
						/* Sanity Check */
						if (!corruptTestLine(field) && field[42] != null && !field[42].trim().equals("")) {

							String mmdd = flightDate.substring(5, 10);
							String flightNumber = field[10];
							String CRS_DEP = field[29];
							String origin = field[14];
							boolean holiday = holidaysMap.contains(mmdd) ? true : false;

							String map_value = dayOfMonth + "," + dayOfWeek + "," + flightDate + "," + airline + ","
									+ flightNumber + "," + CRS_DEP + "," + origin + "," + dest + "," + holiday;
							String key_month = "0" + month;
							
							/* Mapper emits value by key=Month */
							context.write(new Text(key_month), new Text(map_value));
						}
					}
				}

			}

		}

	}

	/* Utility method that converts Time from hhmm to Time in Number of Minutes */
	public static int getMin(String hhmm) {

		if (hhmm.isEmpty()) {
			return 0;
		}

		int min = 0, hr = 0;

		if (hhmm.length() < 3) {
			min = Integer.parseInt(hhmm);

		} else if (hhmm.length() == 3) {

			hr = Integer.parseInt(hhmm.substring(0, 1));
			min = Integer.parseInt(hhmm.substring(1, 3));

		} else if (hhmm.length() == 4) {

			hr = Integer.parseInt(hhmm.substring(0, 2));
			min = Integer.parseInt(hhmm.substring(2, 4));

		}

		return hr * 60 + min;

	}

	/* Sanity checker for Test Data */
	public static boolean corruptTestLine(String[] field) {

		String Origin = field[14], Destination = field[23], OriginCityName = field[15], DestinationCityName = field[24],
				OriginState = field[16], DestinationState = field[25], OriginStateName = field[18],
				DestinationStateName = field[27];

		if (Origin.equals("") || Destination.equals("") || OriginCityName.equals("") || DestinationCityName.equals("")
				|| OriginState.equals("") || DestinationState.equals("") || OriginStateName.equals("")
				|| DestinationStateName.equals("")) {

			return true;

		}

		return false;
	}

	/* Sanity Checker for Training Data */
	public static boolean corruptLine(String[] field) {

		int CRSArrTime = getMin(field[40]);
		int CRSDepTime = getMin(field[29]);
		int CRSElapsedTime = Integer.parseInt(field[50]);
		if (CRSArrTime == 0 || CRSDepTime == 0) {
			return true;
		}

		int timeZone = CRSArrTime - CRSDepTime - CRSElapsedTime;
		if (timeZone % 60 != 0) {
			return true;
		}

		int AirportID = Integer.parseInt(field[20]), AirportSeqID = Integer.parseInt(field[21]),
				CityMarketID = Integer.parseInt(field[22]), StateFips = Integer.parseInt(field[26]),
				Wac = Integer.parseInt(field[28]);

		if (AirportID <= 0 || AirportSeqID <= 0 || CityMarketID <= 0

				|| StateFips <= 0 || Wac <= 0) {

			return true;

		}

		String Origin = field[14], Destination = field[23], OriginCityName = field[15], DestinationCityName = field[24],
				OriginState = field[16], DestinationState = field[25], OriginStateName = field[18],
				DestinationStateName = field[27];

		if (Origin.equals("") || Destination.equals("") || OriginCityName.equals("") || DestinationCityName.equals("")
				|| OriginState.equals("") || DestinationState.equals("") || OriginStateName.equals("")
				|| DestinationStateName.equals("")) {

			return true;

		}

		int Cancelled = Integer.parseInt(field[47]);

		if (Cancelled != 1) {

			int ArrTime = getMin(field[41]), DepTime = getMin(field[30]),
					ActualElapsedTime = Integer.parseInt(field[51]);

			if (((ArrTime - DepTime - ActualElapsedTime - timeZone) / 60) % 24 != 0) {
				return true;
			}

			double ArrDelay = Double.parseDouble(field[42]), ArrDelayMinutes = Double.parseDouble(field[43]),
					ArrDelay15 = Double.parseDouble(field[44]);

			if (ArrDelay > 0 && ArrDelay != ArrDelayMinutes) {
				return true;
			}

			if (ArrDelay < 0 && ArrDelayMinutes != 0) {
				return true;
			}

			if (ArrDelayMinutes >= 15 && ArrDelay15 != 1) {
				return true;
			}

		}

		return false;

	}

	/* Training Data Reducer */
	public static class TrainDataReducer extends Reducer<Text, Text, Text, Text> {
		private MultipleOutputs out;

		protected void setup(Context context) throws IOException, InterruptedException {
			out = new MultipleOutputs<Text, Text>(context);
		}

		public void reduce(Text key, Iterable<Text> values, Context context)

				throws IOException, InterruptedException {
			for (Text val : values) {
				out.write(key, val, key.toString());
			}
		}
	}

	/* Testing Data Reducer */
	public static class TestDataReducer extends Reducer<Text, Text, Text, Text> {
		private MultipleOutputs out;

		protected void setup(Context context) throws IOException, InterruptedException {
			out = new MultipleOutputs<Text, Text>(context);
		}

		public void reduce(Text key, Iterable<Text> values, Context context)

				throws IOException, InterruptedException {
			for (Text val : values) {
				String oldString = val.toString();
				String newString = oldString + ",";
				out.write(key, newString, key.toString());
			}
		}
	}

	
	public static void main(String[] args) throws Exception {

		/* Use 2 Jobs, 1 to read training data and one to read Test data */
		
		Configuration conf = new Configuration();
		conf.set("mapred.textoutputformat.separator", ",");

		Job job1 = Job.getInstance(conf, "Predictions");
		job1.setJarByClass(Predictions.class);
		job1.setMapperClass(TrainDataMapper.class);
		job1.setReducerClass(TrainDataReducer.class);
		job1.setOutputKeyClass(Text.class);
		job1.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job1, new Path(args[0]));
		FileOutputFormat.setOutputPath(job1, new Path(args[2]));
		MultipleOutputs.addNamedOutput(job1, "train", TextOutputFormat.class, LongWritable.class, Text.class);
		job1.waitForCompletion(true);

		Job job2 = Job.getInstance(conf, "Predictions");
		job2.setJarByClass(Predictions.class);
		job2.setMapperClass(TestDataMapper.class);
		job2.setReducerClass(TestDataReducer.class);
		job2.setOutputKeyClass(Text.class);
		job2.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job2, new Path(args[1]));
		FileOutputFormat.setOutputPath(job2, new Path(args[3]));
		MultipleOutputs.addNamedOutput(job2, "test", TextOutputFormat.class, LongWritable.class, Text.class);
		System.exit(job2.waitForCompletion(true) ? 0 : 1);

	}

}
