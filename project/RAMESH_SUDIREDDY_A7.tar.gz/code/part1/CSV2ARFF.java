/* Authors : Nikhil Sudireddy ,  Raghuveer Ramesh */

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import weka.core.Attribute;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

/* Utility class to Convert CSV to ARFF Format */
public class CSV2ARFF {

	public static void main(String[] args) throws Exception {
		if (args.length < 2) {
			System.out.println("\nUsage: CSV2Arff <Input-Folder-CSVs> <OutputFolder-ARFFs> | (Optional) <type>\n");
			System.exit(1);
		}

		/* Load folder containing CSV Files */
		File dir = new File(args[0]);
		File[] listFiles = dir.listFiles();

		/* Load CSV File */
		if (listFiles != null) {

			for (File csv_file : listFiles) {

				String filename = csv_file.getName().toString();
				String new_filename = filename.substring(0, filename.lastIndexOf("."));

				CSVLoader loader = new CSVLoader();

				loader.setSource(new File(args[0] + "/" + filename));
				Instances data = loader.getDataSet();

				/* Add attribute in case of Test data */
				if (args.length == 3) {
					List<String> attList = new ArrayList<String>();

					attList.add("true");
					attList.add("false");

					data.deleteAttributeAt(10);
					data.insertAttributeAt(new Attribute("delay", attList), 10);

				}

				/* Save ARFF */
				ArffSaver saver = new ArffSaver();
				saver.setInstances(data);
				saver.setFile(new File(args[1] + "/" + new_filename + ".arff"));
				saver.setDestination(new File(args[1] + "/" + new_filename + ".arff"));
				saver.writeBatch();
			}
		}
	}
}
