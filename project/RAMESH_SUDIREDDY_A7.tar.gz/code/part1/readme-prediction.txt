1. Untar the file into your working directory.
2. Make sure to have all files in the same working directory. The folder should include 3 java files, two
   shell scripts, one Makefile and one readme file.
3. At the top of the Makefile, you can change the directory paths, bucket names. 
4. Run 'make pseudo' to run the program locally.
5. Run 'make emr' to run the program on the emr cluster.
6. Note: sudo apt-get install jq(Run this command to get 'jq', this is required to run our code in emr).
         And make sure you have execution permissions for the shell scripts.