# Authors : Nikhil Sudireddy ,  Raghuveer Ramesh 
for i in $1/*.csv
do
  sed -i -e '1imonth,dom,dow,fl_date,carrier,flight_num,CRS_DEP,origin,destination,holiday,delay\' $i
done
