/* Authors : Nikhil Sudireddy ,  Raghuveer Ramesh */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import weka.classifiers.bayes.NaiveBayes;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils;

public class EvaluateModel {
	public static void main(String[] args) throws Exception {

		/* <Train-folder> <test-folder> <validation-filePath> */

		/* Read Validation File for comparison and create Map*/

		Map<String,String> validationMap = new HashMap<String,String>();

		InputStream fs = new FileInputStream(args[2]);
		InputStream gs = new GZIPInputStream(fs);
		Reader decoder = new InputStreamReader(gs);

		BufferedReader br = new BufferedReader(decoder);
		br = new BufferedReader(decoder);
		String line;
		while((line = br.readLine()) != null){

			String splits[] = line.split(",");
			validationMap.put(splits[0],splits[1]);
		}


		br.close();


		/* Get folder containing Training and Test files */
		
		

		File train_dir = new File(args[0]);
		File test_dir = new File(args[1]);
		File[]  train_files = train_dir.listFiles();
		File[]  test_files = test_dir.listFiles();

		double tp,fp,tn,fn,total;

		tp = tn = fn = fp = total=0.0;


		/* Loop and compare corresponding training and test files for a given month*/

		if (train_files != null && test_dir != null) {
			for (File train_file : train_files) {
				for (File test_file : test_files) {
					
					String train_file_name = train_file.getName().toString();
					String test_file_name = test_file.getName().toString();
					
					if(train_file_name.equals(test_file_name))
					{

						/* Load Train file for a month*/

						ConverterUtils.DataSource source1 = new ConverterUtils.DataSource(args[0] + "/" + train_file_name);
						Instances train = source1.getDataSet();

						train.setClassIndex(train.numAttributes() - 1);

						/* Train Naive Bayes */
						NaiveBayes naiveBayes = new NaiveBayes();
						naiveBayes.buildClassifier(train);

						/* Load Test File for the corresponding month*/

						ConverterUtils.DataSource source2 = new ConverterUtils.DataSource(args[1] + "/" + test_file_name);
						Instances test = source2.getDataSet();

						test.setClassIndex(test.numAttributes() - 1);


						for (int i = 0; i < test.numInstances(); i++) {

							total++;

							Instance testInstance = test.instance(i);

							String splits[] = testInstance.toString().split(",");

							//[FL_NUM]_[FL_DATE]_[CRS_DEP_TIME]
							String key = splits[5]+"_"+splits[3]+"_"+splits[6];

							String predicted = "";

							double pred;

							try {

								/* Based on Training data, predict outcome for test data */
								pred = naiveBayes.classifyInstance(test.instance(i));
							}
							catch(Exception e){
								continue;
							}

							predicted = test.classAttribute().value((int) pred);


							predicted = predicted.toUpperCase();




							/* Compare prediction result with Validation result */
							String actual = validationMap.get(key);

							if(actual == null)
								continue;

							if(predicted.equals("FALSE") && actual.equals("FALSE")){
								tn ++ ;
							}
							else if(predicted.equals("TRUE") && actual.equals("TRUE")){
								tp ++;

							}
							else if(predicted.equals("TRUE") && actual.equals("FALSE")){

								fp ++;

							}
							else if(predicted.equals("FALSE") && actual.equals("TRUE")){

								fn ++;

							}

						}


					}



				}
			}

			/* Confusion Matrix values */

			double acc = (tp+tn)*100 / (tp + tn + fp + fn);
			System.out.println("Total:"+total + " TP TN FP FN " + tp + " " + tn + " " + fp + " " + fn);
			System.out.println("Accuracy:"+acc);

		}
	}
}
